import './index.css'

const Footer = ()=>(
    <div className='footer-container'>
        <h1 className='footer-heading'>Copyright © 2023 St.Vinsant Pollotti Colage Of Engineering Inc....</h1>
    </div>
)


export default Footer