import Navbar from '../Navbar'
import Footer from '../Footer'

import './index.css'

const Service = ()=>(
    <>
        <Navbar/>
            <div className='service-container'>
                <h1>Service</h1>
            </div>
        <Footer/>
    </>
)

export default Service